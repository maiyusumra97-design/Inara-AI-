# Overview

Inara AI is a video generation platform that creates 4K videos from text descriptions using artificial intelligence. The application allows users to generate videos with customizable parameters including duration (5 seconds to 50 minutes), quality (HD/4K), categories (3D animation, realistic, cartoon, motion graphics), AI voice synthesis, and background music generation. The platform operates on a subscription model at ₹149/month for unlimited video generation with commercial usage rights.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
The client is built as a React Single Page Application (SPA) using:
- **Vite** as the build tool and development server
- **TypeScript** for type safety and better development experience
- **Wouter** for client-side routing instead of React Router
- **TanStack React Query** for server state management and API calls
- **Tailwind CSS** with custom design system for styling
- **shadcn/ui** component library with Radix UI primitives
- **Dark theme** as the primary design approach with neon accent colors

The frontend follows a component-based architecture with separate pages for home and dashboard views. The design emphasizes a futuristic aesthetic with 3D elements, gradient backgrounds, and glassmorphism effects.

## Backend Architecture
The server is built using:
- **Express.js** as the web framework
- **TypeScript** for consistent typing across the stack
- **RESTful API** architecture with routes for users, videos, and payments
- **In-memory storage** implementation (MemStorage class) as the default storage layer
- **Modular route registration** system for clean API organization

The backend implements a storage interface pattern that allows for easy swapping between storage implementations (currently in-memory, but designed to support database backends).

## Data Storage Solutions
Currently uses an in-memory storage system with interfaces designed for:
- **User management** (profiles, subscription status, creation/retrieval)
- **Video management** (creation, status tracking, metadata storage)
- **Payment processing** (transaction records, status updates)

The schema is defined using **Drizzle ORM** with PostgreSQL dialect, indicating preparation for database integration. The database schema includes proper relationships between users, videos, and payments with UUID primary keys.

## Database Schema Design
Three main entities with the following relationships:
- **Users table**: Stores user credentials, subscription status, and expiry dates
- **Videos table**: Linked to users, contains video metadata, processing status, and configuration (voice settings, music settings stored as JSONB)
- **Payments table**: Tracks transactions linked to users with amount, status, and payment method information

## API Structure
RESTful endpoints organized by resource:
- **User endpoints**: Creation, retrieval, subscription management
- **Video endpoints**: Creation, status updates, user video listings
- **Payment endpoints**: Transaction creation, status tracking, user payment history

The API uses proper HTTP status codes and includes comprehensive error handling with structured JSON responses.

## Authentication & Session Management
The codebase includes session management preparation with:
- **connect-pg-simple** for PostgreSQL session storage
- Cookie-based authentication approach
- User identification through UUID system
- Subscription status tracking for access control

## Third-party Integration Readiness
The architecture is prepared for integrating:
- **AI video generation services** (status tracking, processing time monitoring)
- **Payment gateways** (multiple payment methods supported: cards, UPI, net banking)
- **File storage systems** (video URL and thumbnail URL fields)
- **Email/notification services** (user creation and subscription flows)

# External Dependencies

## Core Framework Dependencies
- **React 18** with TypeScript for the frontend application
- **Express.js** with TypeScript for the backend server
- **Vite** for build tooling and development server
- **Node.js** runtime environment

## UI and Styling Dependencies
- **Tailwind CSS** for utility-first styling
- **Radix UI** component primitives for accessibility
- **shadcn/ui** component library for consistent design
- **Lucide React** for iconography
- **class-variance-authority** for component variants

## Data Management Dependencies
- **Drizzle ORM** for database schema and queries
- **@neondatabase/serverless** for PostgreSQL connectivity
- **TanStack React Query** for client-side data fetching and caching
- **Zod** for runtime type validation and schema parsing

## Development and Build Dependencies
- **TypeScript** for static type checking
- **ESBuild** for server-side bundling
- **PostCSS** with Autoprefixer for CSS processing
- **@replit/vite-plugin-runtime-error-modal** for development error handling

## Session and Security Dependencies
- **connect-pg-simple** for PostgreSQL session storage
- **express-session** middleware for session management
- **crypto** module for UUID generation and security functions

## Utility Dependencies
- **date-fns** for date manipulation and formatting
- **clsx** and **tailwind-merge** for conditional CSS classes
- **wouter** for lightweight client-side routing
- **cmdk** for command palette functionality